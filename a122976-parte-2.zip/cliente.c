/******************************************************************************
 ** ISCTE-IUL: Trabalho prático 2 de Sistemas Operativos 2023/2024, Enunciado Versão 3+
 **
 ** Aluno: Nº:122976       Nome:Guilherme Gomes 
 ** Nome do Módulo: cliente.c
 ** Descrição/Explicação do Módulo:
 **
 **
 ******************************************************************************/

#define SO_HIDE_DEBUG                // Uncomment this line to hide all @DEBUG statements
#include "common.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

/**
 * @brief Processamento do processo Cliente
 *        "os alunos não deverão alterar a função main(), apenas compreender o que faz.
 *         Deverão, sim, completar as funções seguintes à main(), nos locais onde está claramente assinalado
 *         '// Substituir este comentário pelo código da função a ser implementado pelo aluno' "
 */
int main () {
    // C1
    checkExistsFifoServidor_C1(FILE_REQUESTS);
    // C2
    triggerSignals_C2();
    // C3 + C4
    CheckIn clientRequest = getDadosPedidoUtilizador_C3_C4();
    // C5
    writeRequest_C5(clientRequest, FILE_REQUESTS);
    // C6
    configureTimer_C6(MAX_ESPERA);
    // C7
    waitForEvents_C7();
    so_exit_on_error(-1, "ERRO: O cliente nunca devia chegar a este ponto");
}

/**
 *  "O módulo Cliente é responsável pela interação com o utilizador.
 *   Após o login do utilizador, este poderá realizar atividades durante o tempo da sessão.
 *   Assim, definem-se as seguintes tarefas a desenvolver:"
 */

/**
 * @brief C1       Ler a descrição da tarefa C1 no enunciado
 * @param nameFifo Nome do FIFO servidor (i.e., FILE_REQUESTS)
 */
void checkExistsFifoServidor_C1 (char *nameFifo) {
    so_debug("< [@param nameFifo:%s]", nameFifo);

    // Verifica se o arquivo existe
    if (access(nameFifo, F_OK) != -1) {
        // Verifica se o arquivo é um FIFO
        struct stat buf;
        if (stat(nameFifo, &buf) == 0 && S_ISFIFO(buf.st_mode)) {
            // FIFO existe
            so_success("C1", "FIFO do Servidor encontrado: %s", nameFifo);
            return; // Retorna após o sucesso
        } else {
            // Arquivo existe, mas não é um FIFO
            so_error("C1", "O arquivo não é um FIFO: %s", nameFifo);
        }
    } else {
        // FIFO não existe
        so_error("C1", "FIFO do Servidor não encontrado: %s", nameFifo);
    }

    // Termina o Cliente após o erro
    exit(1);

    so_debug(">");
}

/**
 * @brief C2   Ler a descrição da tarefa C2 no enunciado
 */
void triggerSignals_C2 () {
    so_debug("<");

    if(signal( SIGUSR1, trataSinalSIGUSR1_C8) == SIG_ERR){
        so_error("C2","");
		exit(1);
    }

    if(signal( SIGHUP, trataSinalSIGHUP_C9) == SIG_ERR){
		so_error("C2","");
		exit(1);
	}

    if(signal( SIGINT, trataSinalSIGINT_C10) == SIG_ERR){
		so_error("C2","");
		exit(1);
	}

    if(signal( SIGALRM, trataSinalSIGALRM_C11) == SIG_ERR){
		so_error("C2","");
		exit(1);
	}
    
    so_debug(">");
}


/**
 * @brief C3+C4    Ler a descrição das tarefas C3 e C4 no enunciado
 * @return CheckIn Elemento com os dados preenchidos. Se nif=-1, significa que o elemento é inválido
 */
CheckIn getDadosPedidoUtilizador_C3_C4 () {
    CheckIn request;
    request.nif = -1;
    so_debug("<");

 // Solicitar e receber o NIF do usuário
    printf("Digite o seu NIF: ");
    // Verificar se o NIF é um número válido
    if (scanf("%d", &request.nif) != 1) {
        // Limpar o buffer de entrada para evitar problemas de loop infinito
        while (getchar() != '\n');
        so_error("C3", "NIF inválido: não é um número");
    } else {
        // Verificar se o NIF tem no máximo 9 dígitos
        if (request.nif <= 0 || request.nif > 999999999 || request.nif == NULL) {
            so_error("C3", "NIF inválido: deve ter no máximo 9 dígitos");    
            exit(1);
        } else {
            // Solicitar e receber a senha do usuário
            printf("Digite a sua senha: ");
            scanf("%s", request.senha);

            // Obtendo o PID do cliente
            request.pidCliente = getpid();

            so_debug("> [@return nif:%d, senha:%s, pidCliente:%d]", request.nif, request.senha, request.pidCliente);
            // Log de sucesso
            so_success("C3", "%d %s %d", request.nif, request.senha, request.pidCliente);
        }
    }
    return request;
}


/**
 * @brief C5       Ler a descrição da tarefa C5 no enunciado
 * @param request  Elemento com os dados a enviar
 * @param nameFifo O nome do FIFO do servidor (i.e., FILE_REQUESTS)
 */
void writeRequest_C5 (CheckIn request, char *nameFifo) {
    so_debug("< [@param request.nif:%d, request.senha:%s, request.pidCliente:%d, nameFifo:%s]",
                                        request.nif, request.senha, request.pidCliente, nameFifo);

 // Abrir o FIFO do servidor para escrita
    int fd = open(nameFifo, O_WRONLY);
    if (fd == -1) {
        so_error("C5", "Erro ao abrir FIFO do servidor");
        exit(1);
    }

    // Escrever as informações no FIFO do servidor
    char buf[100]; // Buffer para armazenar a linha a ser escrita

    // Escrever NIF
    snprintf(buf, sizeof(buf), "%d\n", request.nif);
    if (write(fd, buf, strlen(buf)) == -1) {
        so_error("C5", "Erro ao escrever NIF no FIFO");
        close(fd);
        exit(1);
    }

    // Escrever Senha
    snprintf(buf, sizeof(buf), "%s\n", request.senha);
    if (write(fd, buf, strlen(buf)) == -1) {
        so_error("C5", "Erro ao escrever Senha no FIFO");
        close(fd);
        exit(1);
    }

    // Escrever PID Cliente
    snprintf(buf, sizeof(buf), "%d\n", request.pidCliente);
    if (write(fd, buf, strlen(buf)) == -1) {
        so_error("C5", "Erro ao escrever PID Cliente no FIFO");
        close(fd);
        exit(1);
    }

    // Fechar o FIFO do servidor
    if (close(fd) == -1) {
        so_error("C5", "Erro ao fechar FIFO do servidor");
        exit(1);
    }

    // Log de sucesso
    so_success("C5", "Informações enviadas com sucesso para o FIFO do servidor");

    so_debug(">");
}

/**
 * @brief C6          Ler a descrição da tarefa C6 no enunciado
 * @param tempoEspera o tempo em segundos que queremos pedir para marcar o timer do SO (i.e., MAX_ESPERA)
 */
void configureTimer_C6 (int tempoEspera) {
    so_debug("< [@param tempoEspera:%d]", tempoEspera);

// Configurar o alarme com o tempo de espera especificado
    if (tempoEspera > 0) {
        alarm(tempoEspera);
        so_success("C6", "Espera resposta em %d segundos", tempoEspera);
    } else {
        so_error("C6", "Tempo de espera inválido: %d", tempoEspera);
    }

    so_debug(">");
}

/**
 * @brief C7 Ler a descrição da tarefa C7 no enunciado
 */
void waitForEvents_C7 () {
    so_debug("<");

    pause();

    so_debug(">");
}

/**
 * @brief C8            Ler a descrição da tarefa C8 no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGUSR1_C8 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    // Verificar se o sinal recebido é SIGUSR1
    if (sinalRecebido == SIGUSR1) {
        // Se o sinal recebido for SIGUSR1, exibir mensagem de sucesso e encerrar o Cliente
        so_success("C8", "Check-in concluído com sucesso");
        exit(0); // Terminar o cliente com sucesso
    } else {
        // Se o sinal recebido não for SIGUSR1, exibir mensagem de erro (não esperado)
        so_error("C8", "Sinal inesperado recebido: %d", sinalRecebido);
    }
    so_debug(">");
}

/**
 * @brief C9            Ler a descrição da tarefa C9 no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGHUP_C9 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    // Verificar se o sinal recebido é SIGHUP
    if (sinalRecebido == SIGHUP) {
        // Se o sinal recebido for SIGHUP, exibir mensagem de falha e encerrar o Cliente
        so_success("C9", "Check-in concluído sem sucesso");
        exit(1); // Terminar o cliente indicando falha
    } else {
        // Se o sinal recebido não for SIGHUP, exibir mensagem de erro (não esperado)
        so_error("C9", "Sinal inesperado recebido: %d", sinalRecebido);
    }
    so_debug(">");
}

/**
 * @brief C10           Ler a descrição da tarefa C10 no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGINT_C10 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    // Verificar se o sinal recebido é SIGINT
    if (sinalRecebido == SIGINT) {
        // Se o sinal recebido for SIGINT, exibir mensagem de encerramento e encerrar o Cliente
        so_success("C10", "Cliente: Shutdown");
        exit(0); // Terminar o cliente
    } else {
        // Se o sinal recebido não for SIGINT, exibir mensagem de erro (não esperado)
        so_error("C10", "Sinal inesperado recebido: %d", sinalRecebido);
    }
    so_debug(">");
}

/**
 * @brief C11           Ler a descrição da tarefa C11 no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 
 */
void trataSinalSIGALRM_C11(int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    so_error("C11", "Cliente: Timeout");
    
    so_debug(">");
    exit(1);
}