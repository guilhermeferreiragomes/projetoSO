/******************************************************************************
 ** ISCTE-IUL: Trabalho prático 3 de Sistemas Operativos 2023/2024, Enunciado Versão 3+
 **
 ** Aluno: Nº: 122976       Nome: Guilherme Filipe Ferreira Gomes 
 ** Nome do Módulo: cliente.c
 ** Descrição/Explicação do Módulo:
 **
 **
 ******************************************************************************/

#define SO_HIDE_DEBUG                // Uncomment this line to hide all @DEBUG statements
#include "defines.h"

/*** Variáveis Globais ***/
int msgId;                              // Variável que tem o ID da Message Queue
MsgContent clientRequest;               // Variável que serve para as mensagens trocadas entre Cliente e Servidor
int nrTentativasEscolhaLugar = 0;       // Variável que indica quantas tentativas houve até conseguir encontrar um lugar

/**
 * @brief Processamento do processo Cliente
 *        "os alunos não deverão alterar a função main(), apenas compreender o que faz.
 *         Deverão, sim, completar as funções seguintes à main(), nos locais onde está claramente assinalado
 *         '// Substituir este comentário pelo código da função a ser implementado pelo aluno' "
 */
int main () {
    // C1
    msgId = initMsg_C1();
    so_exit_on_error(msgId, "initMsg_C1");
    // C2
    so_exit_on_error(triggerSignals_C2(), "triggerSignals_C2");
    // C3
    so_exit_on_error(getDadosPedidoUtilizador_C3(), "getDadosPedidoUtilizador_C3");
    // C4
    so_exit_on_error(sendRequest_C4(), "sendRequest_C4");
    // C5: CICLO6
    while (TRUE) {
        // C5
        configureTimer_C5(MAX_ESPERA);
        // C6
        so_exit_on_error(readResponseSD_C6(), "readResponseSD_C6");
        // C7
        int lugarEscolhido = trataResponseSD_C7();
        if (RETURN_ERROR == lugarEscolhido)
            terminateCliente_C9();
        // C8
        if (RETURN_ERROR == sendSeatChoice_C8(lugarEscolhido))
            terminateCliente_C9();
    }
}

/**
 *  "O módulo Cliente é responsável pela interação com o utilizador.
 *   Após o login do utilizador, este poderá realizar atividades durante o tempo da sessão.
 *   Assim, definem-se as seguintes tarefas a desenvolver:"
 */

/**
 * @brief C1: Ler a descrição da tarefa no enunciado
 * @return o valor de msgId em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int initMsg_C1 () {
    so_debug("<");
    struct msqid_ds buf;
    int ret = msgctl(IPC_KEY, IPC_STAT, &buf);
    if (ret == -1 && errno == ENOENT) {
        msgId = msgget(IPC_KEY, IPC_CREAT | 0660);
        if (msgId != -1) {
            so_success("C1", "Message queue created");
        } else {
            so_error("C1", "Failed to create message queue");
        }
    } else {
        msgId = msgget(IPC_KEY, 0);
        if (msgId != -1) {
            so_success("C1", "Message queue exists");
        } else {
            so_error("C1", "Failed to get message queue");
        }
    }
    so_debug("> [@return:%d]", msgId);
    return msgId;
}

/**
 * @brief C2: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int triggerSignals_C2 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");
    if(signal( SIGHUP, trataSinalSIGHUP_C10) == SIG_ERR) {
		so_error("C2","Erro a armar o sinal");
		return -1;
	}

    if(signal( SIGINT, trataSinalSIGINT_C11) == SIG_ERR){ 
		so_error("C2","Erro a armar o sinal");
		return -1;
	}

    if(signal( SIGALRM, trataSinalSIGALRM_C12) == SIG_ERR) {
		so_error("C2","Erro a armar o sinal"); 
		return -1;
	}

    result = 0;
    so_success("C2","");
    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief C3: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int getDadosPedidoUtilizador_C3 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    printf("Introduza o seu NIF: ");
    if (scanf("%d", &clientRequest.msgData.infoCheckIn.nif) != 1) {
        so_error("C3", "Erro: NIF inválido");
        return -1;
    }

    printf("Introduza a sua senha: ");
    scanf("%s", clientRequest.msgData.infoCheckIn.senha);

    result = 0;
    so_success("C3","");
    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief C4: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
/**
 * @brief C4: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int sendRequest_C4 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    clientRequest.msgType = MSGTYPE_LOGIN;
    clientRequest.msgData.infoCheckIn.pidCliente = getpid();
    clientRequest.msgData.infoCheckIn.pidServidorDedicado = PID_INVALID;  // Inicializar como PID_INVALID

    size_t msgsz = sizeof(clientRequest.msgData);

    if (msgsnd(msgId, &clientRequest, msgsz, 0) == -1) {
        so_error("C4", "Erro ao enviar mensagem");
        return -1;
    }

    printf("(C4) <%d> <%s> <%d>\n", clientRequest.msgData.infoCheckIn.nif, clientRequest.msgData.infoCheckIn.senha, clientRequest.msgData.infoCheckIn.pidCliente);

    result = 0;
    so_success("C4", "");
    so_debug("> [@return:%d]", result);
    return result;
}


/**
 * @brief C5: Ler a descrição da tarefa no enunciado
 * @param tempoEspera o tempo em segundos que queremos pedir para marcar o timer do SO (i.e., MAX_ESPERA)
 */
void configureTimer_C5 (int tempoEspera) {
    so_debug("< [@param tempoEspera:%d]", tempoEspera);

    alarm(tempoEspera);

    so_success("C5", "Espera resposta em %d segundos", tempoEspera);
    so_debug(">");
}

/**
 * @brief C6: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int readResponseSD_C6 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    if (msgrcv(msgId, &clientRequest, sizeof(clientRequest.msgData), getpid(), 0) == -1) {
        so_error("C6", "Erro ao ler mensagem");
        return -1;
    }

    result = 0;
    so_success("C6", "%d %d %d", clientRequest.msgData.infoCheckIn.nif, clientRequest.msgData.infoCheckIn.lugarEscolhido, getpid());
    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief C7: Ler a descrição da tarefa no enunciado
 * @return Nº do lugar escolhido (0..MAX_SEATS-1) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int trataResponseSD_C7 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    // Desarmar o alarme
    alarm(0);

    // C7.2: Verifica se o servidor dedicado indicou que o login falhou
    if (clientRequest.msgData.infoCheckIn.pidServidorDedicado == PID_INVALID) {
        so_error("C7.2", "Erro: Login falhou");
        terminateCliente_C9();
        // Retornar um erro para indicar falha no login
        return RETURN_ERROR;
    }

    // C7.3: Verifica se a reserva foi concluída
    if (clientRequest.msgData.infoCheckIn.lugarEscolhido != EMPTY_SEAT) {
        so_success("C7.3", "Reserva concluída: %s %s %d", clientRequest.msgData.infoVoo.origem, clientRequest.msgData.infoVoo.destino, clientRequest.msgData.infoCheckIn.lugarEscolhido);
        terminateCliente_C9();
        // Retornar o número do lugar escolhido
        return clientRequest.msgData.infoCheckIn.lugarEscolhido;
    }

    // C7.4: O campo lugarEscolhido tem o valor EMPTY_SEAT, significa que o Servidor Dedicado está a pedir para que o utilizador escolha um novo lugar
    if (nrTentativasEscolhaLugar == 0) {
        so_success("C7.4.1", "Primeira tentativa de escolha de lugar");
    } else {
        so_error("C7.4.1", "Erro na reserva de lugar");
    }
    nrTentativasEscolhaLugar++;

    // Mostra ao utilizador a lista de lugares disponíveis
    printf("Lugares disponíveis:");
    for (int i = 0; i < MAX_SEATS; i++) {
        if (clientRequest.msgData.infoVoo.lugares[i] == EMPTY_SEAT) {
            printf(" %d", i);
        }
    }
    printf("\nEscolha o lugar pretendido: ");
    int lugarEscolhido;
    if (scanf("%d", &lugarEscolhido) != 1 || lugarEscolhido < 0 || lugarEscolhido >= MAX_SEATS || clientRequest.msgData.infoVoo.lugares[lugarEscolhido] != EMPTY_SEAT) {
        so_error("C7.4.3", "Erro: Lugar inválido");
        // Retornar um erro para indicar que houve um problema na escolha do lugar
        return RETURN_ERROR;
    } else {
        so_success("C7.4.3", "%d", lugarEscolhido);
        // Retornar o número do lugar escolhido
        return lugarEscolhido;
    }

    so_debug("> [@return:%d]", result);
    return result; // Essa linha é inacessível, pois as instruções de retorno anteriores já terão sido executadas
}

/**
 * @brief C8: Ler a descrição da tarefa no enunciado
 * @param lugarEscolhido índice do array lugares que o utilizador escolheu, entre 0 e MAX_SEATS-1
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int sendSeatChoice_C8 (int lugarEscolhido) {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("< [@param lugarEscolhido:%d]", lugarEscolhido);

    // Preencher os campos da mensagem clientRequest
    clientRequest.msgType = clientRequest.msgData.infoCheckIn.pidServidorDedicado;
    clientRequest.msgData.infoCheckIn.nif = clientRequest.msgData.infoCheckIn.nif;
    clientRequest.msgData.infoCheckIn.lugarEscolhido = lugarEscolhido;
    clientRequest.msgData.infoCheckIn.pidCliente = getpid();

    // Calcular o tamanho da mensagem a ser enviada, que é o tamanho de msgData
    size_t msgsz = sizeof(clientRequest.msgData);

    // Enviar a mensagem para a fila de mensagens
    if (msgsnd(msgId, &clientRequest, msgsz, 0) == -1) {
        so_error("C8", "Erro ao enviar mensagem");
        return RETURN_ERROR;
    }

    // Log da mensagem enviada para depuração
    so_debug("(C8) <%d> <%d> <%d>", clientRequest.msgData.infoCheckIn.nif, clientRequest.msgData.infoCheckIn.lugarEscolhido, clientRequest.msgData.infoCheckIn.pidCliente);

    // Indicar sucesso
    result = RETURN_SUCCESS;
    so_success("C8", "");
    so_debug("> [@return:%d]", result);
    return result;
}


/**
 * @brief C9: Ler a descrição da tarefa no enunciado
 */
void terminateCliente_C9 () {
    so_debug("<");

    // Verificar se a mensagem clientRequest indica que o login falhou
    if (clientRequest.msgData.infoCheckIn.pidServidorDedicado == PID_INVALID) {
        so_error("C9", "Erro: Login falhou");
        exit(1);
    } else {
        so_success("C9", "Login concluído com sucesso");
        if (kill(clientRequest.msgData.infoCheckIn.pidServidorDedicado, SIGUSR1) == -1) {
            so_error("C9", "Erro ao enviar sinal SIGUSR1");
        }
        exit(1);
    }
    so_debug(">");
}

/**
 * @brief C10: Ler a descrição da tarefa no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGHUP_C10 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    so_success("C10","Check-in concluído sem sucesso");
    exit(0);

    so_debug(">");
}


/**
 * @brief C11: Ler a descrição da tarefa no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGINT_C11 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    so_success("C11","Cliente: Shutdown");
    terminateCliente_C9();
    exit(0);

    so_debug(">");
}

/**
 * @brief C12: Ler a descrição da tarefa no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGALRM_C12 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    so_error("C12","Cliente: Timeout");
    terminateCliente_C9();
    exit(0);

    so_debug(">");
}