#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. ./so_utils.sh                     ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024, Enunciado Versão 3+
##
## Aluno: Nº:122976       Nome:Guilherme Gomes
## Nome do Módulo: S5. Script: menu.sh
## Descrição/Explicação do Módulo: Este é ultimo modulo e invoca todos os outros scripts permitindo ao utilizador exercer todas as funções criadas ate agora (regitrar, comprar, atualizar e obter estatisticas). O utilizador pode selecionar a opção a partir do menu, sendo este o ultimo script da parte 1 do projeto (finalmente).
##
##
###############################################################################

## Este script invoca os scripts restantes, não recebendo argumentos. Atenção: Não é suposto que volte a fazer nenhuma das funcionalidades dos scripts anteriores. O propósito aqui é simplesmente termos uma forma centralizada de invocar os restantes scripts.


while true; do
    # seleção da opção
    echo "MENU:
1: Regista/Atualiza saldo do passageiro
2: Reserva/Compra de bilhetes
3: Atualiza Estado dos voos
4: Estatísticas - Passageiros
5: Estatísticas - Top Voos + Rentáveis
0: Sair
"
read -p "Opção: " option

    # execução consoante a opção selecionada
    case $option in
        1)
            # registar o passageiros (ou atualizar caso ja exista)
            echo "Regista passageiro / Atualiza saldo passageiro:"
            read -p "Indique o nome: " Nome
            read -p "Indique a senha: " Senha
            read -p "Para registar o passageiro, insira o NIF (deixe em branco se só deseja atualizar saldo): " NIF
            read -p "Indique o saldo a adicionar ao passageiro: " Saldo_a_adicionar
            if [ -z "$NIF" ]; then
                ./regista_passageiro.sh "$Nome" "$Senha" "$Saldo_a_adicionar" "" 
            else
                ./regista_passageiro.sh "$Nome" "$Senha" "$Saldo_a_adicionar" "$NIF" 
            fi
            so_success S5.2.2.1
            ;;
        2)
            # compra de bilhetes
            ./compra_bilhete.sh
            so_success S5.2.2.2
            ;;
        3)
            # atualizar o estado do voo
            ./estado_voos.sh
            so_success S5.2.2.3
            ;;
        4)
            # exibir as estatisticas consoante os passageiros
            ./stats.sh passageiros
            so_success S5.2.2.4
            ;;
        5)
            # estatisticas dos voos mais lucrativos
            read -p "Indique o número de voos a listar: " n_voos
            ./stats.sh top $n_voos
            so_success S5.2.2.5
            ;;
        0)
            break
            ;;
        *)
            # caso a opção seja inválida
            so_error S5.2.1 $option
            ;;
    esac
done