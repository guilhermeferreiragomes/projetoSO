#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. so_utils.sh                       ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024
##
## Aluno: Nº:122976       Nome:Guilherme Gomes
## Nome do Módulo: S4. Script: stats.sh
## Descrição/Explicação do Módulo: Neste módulo são fornecidas informações com base nos argumentos passados. São criados arquivos listando os utilizadores que fizeram reservas, ordenando-os e calculando o seu total de compras. É ainda listado o numero dos voos mais lucrativos.
##
##
###############################################################################

## Este script obtém informações sobre o sistema, afixando resultados diferentes no STDOUT consoante os argumentos passados na sua invocação. A sintaxe resumida é: ./stats.sh <passageiros>|<top <nr>>
## S4.1. Validações:
## S4.1.1. Valida os argumentos recebidos e, conforme os mesmos, o número e tipo de argumentos recebidos. Se não respeitarem a especificação, dá so_error e termina. Caso contrário, dá so_success.

# verificar o numero de argumentos
if ! [ "$#" -eq 1 ]; then
    so_error S4.1.1
else
    so_success S4.1.1

    # verificar o tipo de argumento
    if ! [[ "$1" != "passageiros" && ! "$1" =~ ^top\ [0-9]+$ ]]; then
        so_success S4.1.1     
    else
        so_error S4.1.1
        exit 1
    fi
fi

## S4.2. Invocação do script:
## S4.2.1. Se receber o argumento passageiros, (i.e., ./stats.sh passageiros) cria um ficheiro stats.txt onde lista o nome de todos os utilizadores que fizeram reservas, por ordem decrescente de número de reservas efetuadas, e mostrando o seu valor total de compras. Em caso de erro (por exemplo, se não conseguir ler algum ficheiro necessário), dá so_error e termina. Caso contrário, dá so_success e cria o ficheiro. Em caso de empate no número de reservas, lista o primeiro do ficheiro. Preste atenção ao tratamento do singular e plural quando se escreve “reserva” no ficheiro).


# se o argumento dor passageiros cria o ficheiro
if [ "$1" = "passageiros" ]; then
    touch stats.txt
    IDs=$(sort -t: -k6 -nr relatorio_reservas.txt | cut -d: -f6 | sort | uniq -c)
    # ordenar por ordem decrescente
    echo "$IDs" | sort -nr | while read count id; do
    same_name=$(grep -w "^$id" passageiros.txt | cut -d: -f3)
    # calcula o total de compras
    total_price=$(grep -w "$id" relatorio_reservas.txt | awk -F: '{sum += $5} END {print sum}')
        if [ $count -gt 1 ]; then
            echo "$same_name: $count reservas; $total_price€" >> stats.txt
        else
            echo "$same_name: $count reserva; $total_price€" >> stats.txt
        fi
    done

    # verificar se o arquivo foi criado e nao esta vazio
    if ! [[ ! -f stats.txt || $(cat stats.txt | wc -l) -eq 0 ]]; then
        so_success S4.2.1
    else
        so_error S4.2.1
        exit 1
    fi




