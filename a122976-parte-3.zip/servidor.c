/******************************************************************************
 ** ISCTE-IUL: Trabalho prático 3 de Sistemas Operativos 2023/2024, Enunciado Versão 1+
 **
 ** Aluno: Nº: 122976      Nome: Guilherme Filipe Ferreira Gomes
 ** Nome do Módulo: servidor.c
 ** Descrição/Explicação do Módulo:
 **
 **
 ******************************************************************************/

#define SO_HIDE_DEBUG                // Uncomment this line to hide all @DEBUG statements
#include "defines.h"

/*** Variáveis Globais ***/
int shmId;                              // Variável que tem o ID da Shared Memory
int msgId;                              // Variável que tem o ID da Message Queue
int semId;                              // Variável que tem o ID do Grupo de Semáforos
MsgContent clientRequest;               // Variável que serve para as mensagens trocadas entre Cliente e Servidor
DadosServidor *database = NULL;         // Variável que vai ficar com UM POINTER PARA a memória partilhada
int indexClient = -1;                   // Índice do passageiro que fez o pedido ao servidor/servidor dedicado na BD
int indexFlight = -1;                   // Índice do voo do passageiro que fez o pedido ao servidor/servidor dedicado na BD
int nrServidoresDedicados = 0;          // Número de servidores dedicados (só faz sentido no processo Servidor)

/**
 * @brief Processamento do processo Servidor e dos processos Servidor Dedicado
 *        "os alunos não deverão alterar a função main(), apenas compreender o que faz.
 *         Deverão, sim, completar as funções seguintes à main(), nos locais onde está claramente assinalado
 *         '// Substituir este comentário pelo código da função a ser implementado pelo aluno' "
 */
int main () {
    // S1
    shmId = initShm_S1();
    if (RETURN_ERROR == shmId) terminateServidor_S7();
    // S2
    msgId = initMsg_S2();
    if (RETURN_ERROR == msgId) terminateServidor_S7();
    // S3
    semId = initSem_S3();
    if (RETURN_ERROR == semId) terminateServidor_S7();
    // S4
    if (RETURN_ERROR == triggerSignals_S4()) terminateServidor_S7();

    // S5: CICLO1
    while (TRUE) {
        // S5
        int result = readRequest_S5();
        if (CICLO1_CONTINUE == result) // S5: "Se receber um sinal (...) retorna o valor CICLO1_CONTINUE"
            continue;                  // S5: "para que main() recomece automaticamente o CICLO1 no passo S5"
        if (RETURN_ERROR == result) terminateServidor_S7();
        // S6
        int pidServidorDedicado = createServidorDedicado_S6();
        if (pidServidorDedicado > 0)   // S6: "o processo Servidor (pai) (...) retorna um valor > 0"
            continue;                  // S6: "(...) recomeça o Ciclo1 no passo S4 (ou seja, volta a aguardar novo pedido)"
        if (RETURN_ERROR == pidServidorDedicado) terminateServidor_S7();
        // S6: "o Servidor Dedicado (...) retorna 0 para que main() siga automaticamente para o passo SD10

        // SD10
        if (RETURN_ERROR == triggerSignals_SD10()) terminateServidorDedicado_SD18();
        // SD11
        indexClient = searchClientDB_SD11();
        int erroValidacoes = TRUE;
        if (RETURN_ERROR != indexClient) {
            // SD12: "Se o passo SD11 concluiu com sucesso: (...)"
            indexFlight = searchFlightDB_SD12();
            if (RETURN_ERROR != indexFlight) {
                // SD13: "Se os passos SD11 e SD12 tiveram sucesso, (...)"
                if (!updateClientDB_SD13())
                    erroValidacoes = FALSE; // erroValidacoes = "houve qualquer erro nas validações dos passos SD11, SD12, ou SD13"
            }
        }
        // SD14: CICLO5
        int escolheuLugarDisponivel = FALSE;
        while (!escolheuLugarDisponivel) {
            // SD14.1: erroValidacoes = "houve qualquer erro nas validações dos passos SD11, SD12, ou SD13"
            if (RETURN_ERROR == sendResponseClient_SD14(erroValidacoes)) terminateServidorDedicado_SD18();
            if (erroValidacoes)
                terminateServidorDedicado_SD18();

            // SD15: "Se os pontos anteriores tiveram sucesso, (...)"
            if (RETURN_ERROR == readResponseClient_SD15()) terminateServidorDedicado_SD18();
            // SD16
            if (RETURN_ERROR == updateFlightDB_SD16())  // SD16: "Se lugarEscolhido no pedido NÃO estiver disponível (...) retorna erro (-1)"
                continue;                               // SD16: "para que main() recomece o CICLO5 em SD14"
            else
                escolheuLugarDisponivel = TRUE;
        }
        sendConfirmationClient_SD17();
        terminateServidorDedicado_SD18();
    }
}

/**
 *  "O módulo Servidor é responsável pelo processamento do check-in dos passageiros.
 *   Está dividido em duas partes, um Servidor (pai) e zero ou mais Servidores Dedicados (filhos).
 *   Este módulo realiza as seguintes tarefas:"
 */

/**
 * @brief S1: Ler a descrição da tarefa no enunciado
 * @return o valor de shmId em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "defines.h"

#define KEY_SHM 1234
#define SHM_SIZE 1024

int initShm_S1 () {
    shmId = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");
     // Verifica se os arquivos bd_passageiros.dat e bd_voos.dat existem e têm permissões de leitura e escrita
       if (access("bd_passageiros.dat", R_OK | W_OK) == -1 || access("bd_voos.dat", R_OK | W_OK) == -1) {
        so_error("S1.1", "");
        return shmId;
     } else {
        so_success("S1.1", "");
    }

    // S1.2
    shmId = shmget(IPC_KEY, sizeof(DadosServidor), 0);
    if (shmId != -1) {
        database = shmat(shmId, NULL, 0);
        if (database != (void*) -1) {
            so_success("S1.2", "%d", shmId);
            so_success("S1.2.1", "%d", shmId); 
            return shmId;
        } else {
            so_error("S1.2", "Falha ao anexar a memória");
            return RETURN_ERROR;
        }
   }
       
    so_error("S1.2", "Memória não encontrada");

    // S1.3
    if (errno != ENOENT) {
        so_error("S1.3", "");
        return shmId;
    }
    so_success("S1.3", "Memória compartilhada não encontrada, a criar nova");

    // S1.4
    shmId = shmget(IPC_KEY, sizeof(DadosServidor), IPC_CREAT | 0666);
    if (shmId == -1) {
        so_error("S1.4", "");
        return shmId;
    }
    database = shmat(shmId, NULL, 0);
    if (database == (void*) -1) {
        so_error("S1.4", "");
        return shmId;
    }
    so_success("S1.4", "%d", shmId);

    // S1.5
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        database->listClients[i].nif = PASSENGER_NOT_FOUND;
    }
    for (int i = 0; i < MAX_FLIGHTS; i++) {
        database->listFlights[i].nrVoo[0] = FLIGHT_NOT_FOUND[0];
    }
    so_success("S1.5", "");

    // S1.6
    FILE *fp = fopen("bd_passageiros.dat", "rb");
    if (!fp) {
        so_error("S1.6", "");
        return shmId;
    }
    fread(database->listClients, sizeof(CheckIn), MAX_PASSENGERS, fp);
    fclose(fp);
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        database->listClients[i].pidCliente = PID_INVALID;
        database->listClients[i].pidServidorDedicado = PID_INVALID;
    }
    so_success("S1.6", "");

    // S1.7
    fp = fopen("bd_voos.dat", "rb");
    if (!fp) {
        so_error("S1.7", "");
        return shmId;
    }
    fread(database->listFlights, sizeof(Voo), MAX_FLIGHTS, fp);
    fclose(fp);
    so_success("S1.7", "%d", shmId);
    so_debug("> [@return:%d]", shmId);
    return shmId;
}

/**
 * @brief S2: Ler a descrição da tarefa no enunciado
 * @return o valor de msgId em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int initMsg_S2() {
    int msgId = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    // S2.1: Se a MSG já existir, deve apagá-la
    msgId = msgget(IPC_KEY, 0); // Tenta obter a fila de mensagens
    if (msgId != -1) {
        if (msgctl(msgId, IPC_RMID, NULL) == -1) { // Se existir, tenta remover
            so_error("S2.1", ""); // Mensagem de erro
            return msgId; // Retorna o id da fila de mensagens (mesmo que não tenha conseguido remover)
        }
        so_success("S2.1", ""); // Se conseguiu remover com sucesso, emite uma mensagem de sucesso
    }

    // S2.2: Cria a Message Queue com a KEY IPC_KEY
    msgId = msgget(IPC_KEY, IPC_CREAT | IPC_EXCL | 0666); // Cria a fila de mensagens
    if (msgId == -1) { // Verifica se houve erro na criação
        so_error("S2.2", ""); // Emite uma mensagem de erro
        return msgId; // Retorna o id da fila de mensagens (que é -1, indicando erro)
    }
    so_success("S2.2", "%d", msgId); // Emite uma mensagem de sucesso
    so_debug("> [@return:%d]", msgId); // Debug para mostrar o valor de retorno
    return msgId; // Retorna o id da fila de mensagens
}


/**
 * @brief S3: Ler a descrição da tarefa no enunciado
 * @return o valor de semId em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int initSem_S3 () {
    semId = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    
// S3.1 Se o SEM já existir, deve apagá-lo
    semId = semget(IPC_KEY, 3, 0666);
    if (semId != -1) {
        if (semctl(semId, 0, IPC_RMID) == -1) {
            so_error("S3.1", "Erro ao remover o grupo de semáforos existente");
            so_debug("> [@return:%d]", semId);
            return RETURN_ERROR;
        }
        so_success("S3.1", "Grupo de semáforos existente removido com sucesso");
    }

    // S3.2 Cria um grupo de 3 (três) semáforos com a KEY IPC_KEY
    semId = semget(IPC_KEY, 3, IPC_CREAT | 0666);
    if (semId == -1) {
        so_error("S3.2", "Erro ao criar o grupo de semáforos");
        so_debug("> [@return:%d]", semId);
        return RETURN_ERROR;
    }
    so_success("S3.2", "%d", semId);

    // S3.3 Inicia os semáforos
    if (semctl(semId, 0, SETVAL, 1) == -1) {
        so_error("S3.3", "Erro ao inicializar o semáforo SEM_PASSAGEIROS");
        so_debug("> [@return:%d]", semId);
        return RETURN_ERROR;
    }
    if (semctl(semId, 1, SETVAL, 1) == -1) {
        so_error("S3.3", "Erro ao inicializar o semáforo SEM_VOOS");
        so_debug("> [@return:%d]", semId);
        return RETURN_ERROR;
    }
    if (semctl(semId, 2, SETVAL, 0) == -1) {
        so_error("S3.3", "Erro ao inicializar o semáforo SEM_NR_SRV_DEDICADOS");
        so_debug("> [@return:%d]", semId);
        return RETURN_ERROR;
    }
    so_success("S3.3", "");
    so_debug("> [@return:%d]", semId);
    return semId;
}

/**
 * @brief S4: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int triggerSignals_S4 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    // Arma o sinal SIGINT
    if (signal(SIGINT, trataSinalSIGINT_S8) == SIG_ERR) {
        so_error("S4", "Erro ao armar o sinal SIGINT");
        so_debug("> [@return:%d]", result);
        return result;
    }

    // Arma o sinal SIGCHLD
    if (signal(SIGCHLD, trataSinalSIGCHLD_S9) == SIG_ERR) {
        so_error("S4", "Erro ao armar o sinal SIGCHLD");
        so_debug("> [@return:%d]", result);
        return result;
    }

    so_success("S4", "Sinais armados com sucesso");
    result = RETURN_SUCCESS;

    so_debug("> [@return:%d]", result);
    return result;
}

    /**
     * @brief S5: O CICLO1 já está a ser feito na função main(). Ler a descrição da tarefa no enunciado
     * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
     */
    int readRequest_S5() {
        int result = RETURN_ERROR; // Por omissão, retorna erro
        so_debug("<");

        // Definir uma estrutura para armazenar a mensagem recebida
        MsgContent msg;

        // Ler da MSG uma mensagem do tipo MSGTYPE_LOGIN
        if (msgrcv(msgId, &msg, sizeof(msg.msgData), MSGTYPE_LOGIN, 0) == -1) {
            if (errno == EINTR) {
                so_debug("Recebeu um sinal durante a leitura");
                return CICLO1_CONTINUE; // Retorna CICLO1_CONTINUE se receber um sinal
            } else {
                so_error("S5", "Erro na leitura da mensagem da MSG");
                return RETURN_ERROR; // Retorna erro em caso de outro tipo de erro na leitura
            }
        }

        // Se não houve erros na leitura, retorna sucesso com os dados lidos
        so_success("S5", "%ld %s %d", msg.msgData.infoCheckIn.nif, msg.msgData.infoCheckIn.senha, msg.msgData.infoCheckIn.pidCliente);
        result = RETURN_SUCCESS; // Define resultado como sucesso

        so_debug("> [@return:%d]", result);
        return result;
    }

/**
 * @brief S6: Ler a descrição da tarefa no enunciado
 * @return PID do processo filho, se for o processo Servidor (pai),
 *         0 se for o processo Servidor Dedicado (filho),
 *         ou PID_INVALID (-1) em caso de erro
 */
int createServidorDedicado_S6 () {
    int pid_filho = fork(); // Criar processo filho (Servidor Dedicado)

    if (pid_filho == -1) {
        // Erro ao criar processo filho
        so_error("S6", "Erro ao criar o Servidor Dedicado");
        return RETURN_ERROR;
    } else if (pid_filho == 0) {
        // Código executado pelo processo filho (Servidor Dedicado)
        so_success("S6", "Servidor Dedicado: Nasci");
        return 0;
    } else {
        // Código executado pelo processo pai (Servidor)
        nrServidoresDedicados++;
        so_success("S6", "Servidor: Iniciei SD %d", pid_filho);
        return pid_filho; // Retornar sucesso ao pai
    }
}

/**
 * @brief S7: Ler a descrição da tarefa no enunciado
 */
void terminateServidor_S7 () {
    so_debug("<");
    so_success("S7", "Servidor: Start Shutdown");

    // S7.1: Verifica se existe SHM aberta e apontada pela variável database
    if (database == NULL) {
        so_error("S7.1", "Shared Memory não está aberta ou database não está apontando para ela");
    } else {
        so_success("S7.1", "");

        // S7.2: CICLO2 - Percorre a lista de passageiros de database
        for (int i = 0; i < MAX_PASSENGERS; i++) {
            if (database->listClients[i].pidServidorDedicado > 0) {
                kill(database->listClients[i].pidServidorDedicado, SIGUSR2);
                so_success("S7.2", "Servidor: Shutdown SD %d", database->listClients[i].pidServidorDedicado);
            }
        }

        // S7.3: Aguarda que TODOS os Servidores Dedicados terminem (algoritmo "barreira")
        struct sembuf sops = {
            SEM_NR_SRV_DEDICADOS, -nrServidoresDedicados, 0};
        
        semop(semId, &sops, 1);
        so_success("S7.3", "");

        // S7.4: Reescreve os ficheiros bd_passageiros.dat e bd_voos.dat com a informação das listas de passageiros e de voos da memória partilhada
        FILE *f = fopen("bd_passageiros.dat", "wb");
        if (f) {
            fwrite(database->listClients, sizeof(CheckIn), MAX_PASSENGERS, f);
            fclose(f);

            f = fopen("bd_voos.dat", "wb");
            if (f) {
                fwrite(database->listFlights, sizeof(Voo), MAX_FLIGHTS, f);
                fclose(f);
                so_success("S7.4", "");
            } else {
                so_error("S7.4", "Erro ao abrir bd_voos.dat para escrita");
            }
        } else {
            so_error("S7.4", "Erro ao abrir bd_passageiros.dat para escrita");
        }
    }

    // S7.5: Apaga todos os elementos IPC (SHM, SEM e MSG) que existam com a KEY IPC_KEY
    if (shmId != RETURN_ERROR) {
        shmctl(shmId, IPC_RMID, NULL);
    }
    if (semId != RETURN_ERROR) {
        semctl(semId, 0, IPC_RMID, NULL);
    }
    if (msgId != RETURN_ERROR) {
        msgctl(msgId, IPC_RMID, NULL);
    }
    so_success("S7.5", "Servidor: End Shutdown");
    so_debug(">");
    exit(0);
}

/**
 * @brief S8: Ler a descrição da tarefa no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGINT_S8 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    // Dá so_success e segue para o passo S7 (encerramento do Servidor)
    so_success("S8", "Recebido sinal SIGINT. Iniciando encerramento do Servidor.");
    terminateServidor_S7();

    so_debug(">");
}

/**
 * @brief S9: Ler a descrição da tarefa no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGCHLD_S9 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    // Substituir este comentário pelo código da função a ser implementado pelo aluno

    so_debug(">");
}

/**
 * @brief SD10: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int triggerSignals_SD10 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    // Arma o sinal SIGUSR1
    if (signal(SIGUSR1, trataSinalSIGUSR1_SD19) == SIG_ERR) {
        so_error("SD10", "Erro ao armar o sinal SIGUSR1");
        so_debug("> [@return:%d]", result);
        return result;
    }

    // Arma o sinal SIGUSR2
    if (signal(SIGUSR2, trataSinalSIGUSR2_SD20) == SIG_ERR) {
        so_error("SD10", "Erro ao armar o sinal SIGUSR2");
        so_debug("> [@return:%d]", result);
        return result;
    }

    // Programa o sinal SIGINT para ser ignorado
    if (signal(SIGINT, SIG_IGN) == SIG_ERR) {
        so_error("SD10", "Erro ao ignorar o sinal SIGINT");
        so_debug("> [@return:%d]", result);
        return result;
    }

    so_success("SD10", "Sinais armados com sucesso");
    result = RETURN_SUCCESS;
    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief SD11: Ler a descrição da tarefa no enunciado
 * @return indexClient em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int searchClientDB_SD11 () {
    indexClient = -1;    // SD11: Inicia a variável indexClient a -1 (índice da lista de passageiros de database)
    so_debug("<");
 // SD11.1 CICLO3: Percorre a lista de passageiros de database
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        // SD11.2 Valida se o campo nif é igual ao campo nif do pedido clientRequest
        if (database->listClients[i].nif == clientRequest.msgData.infoCheckIn.nif) {
            // SD11.3 Compara o campo senha do passageiro com o do pedido clientRequest
            if (strcmp(database->listClients[i].senha, clientRequest.msgData.infoCheckIn.senha) == 0) {
                indexClient = i;
                so_success("SD11.3", "%d", indexClient);
                so_debug("> [@return:%d]", indexClient);
                return indexClient; // Retorna indexClient em caso de sucesso
            } else {
                so_error("SD11.3", "Cliente %d: Senha errada", clientRequest.msgData.infoCheckIn.nif);
                so_debug("> [@return:%d]", RETURN_ERROR);
                return RETURN_ERROR; // Retorna erro se a senha estiver errada
            }
        }
    }
// Se chegou ao final da lista sem encontrar o passageiro com o NIF do pedido clientRequest
    so_error("SD11.1", "Cliente %d: não encontrado", clientRequest.msgData.infoCheckIn.nif);
  
    so_debug("> [@return:%d]", indexClient);
    return indexClient;
}
/**
 * @brief SD12: Ler a descrição da tarefa no enunciado
 * @return indexFlight em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int searchFlightDB_SD12 () {
    indexFlight = -1;    // SD12: Inicia a variável indexFlight a -1 (índice da lista de voos de database)
    so_debug("<");

    // SD12.1 CICLO4: Percorre a lista de voos de database
    for (int i = 0; i < MAX_FLIGHTS; i++) {
        // SD12.2 Valida se o campo nrVoo é igual ao campo nrVoo do passageiro indexClient
        if (strcmp(database->listFlights[i].nrVoo, database->listClients[indexClient].nrVoo) == 0) {
            indexFlight = i;
            so_success("SD12.2", "%d", indexFlight);
            so_debug("> [@return:%d]", indexFlight);
            return indexFlight; // Retorna indexFlight em caso de sucesso
        }
    }

    // Se chegou ao final da lista sem encontrar o nrVoo do passageiro indexClient
    so_error("SD12.1", "Voo %s: não encontrado", database->listClients[indexClient].nrVoo);

    so_debug("> [@return:%d]", indexFlight);
    return indexFlight;
}

/**
 * @brief SD13: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int updateClientDB_SD13 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");
// SD13.1 Dá so_success "Start Check-in: <NIF> <pidCliente>"
    so_success("SD13.1", "Start Check-in: %d %d", clientRequest.msgData.infoCheckIn.nif, clientRequest.msgData.infoCheckIn.pidCliente);

    // Operações de semáforo para entrar na seção crítica
    struct sembuf sem_op;
    sem_op.sem_num = SEM_PASSAGEIROS;
    sem_op.sem_op = -1; // Decrementa o semáforo para bloquear
    sem_op.sem_flg = 0;
    if (semop(semId, &sem_op, 1) == -1) {
        so_error("SD13", "Erro ao bloquear o semáforo SEM_PASSAGEIROS");
        so_debug("> [@return:%d]", result);
        return result; // Retorna erro se não conseguir bloquear o semáforo
    }

    // SD13.2 Valida se pidCliente é PID_INVALID e lugarEscolhido é EMPTY_SEAT
    if (database->listClients[indexClient].pidCliente != PID_INVALID || database->listClients[indexClient].lugarEscolhido != EMPTY_SEAT) {
        // Libera o semáforo antes de retornar erro
        sem_op.sem_op = 1; // Incrementa o semáforo para desbloquear
        semop(semId, &sem_op, 1);
        
        so_error("SD13.2", "Cliente %d: Já fez check-in", clientRequest.msgData.infoCheckIn.nif);
        so_debug("> [@return:%d]", result);
        return result; // Retorna erro se já fez check-in
    }

    // SD13.3 Aguarda (sleep) 4 segundos
    sleep(4);

    // SD13.4 Atualiza os campos pidCliente e pidServidorDedicado
    database->listClients[indexClient].pidCliente = clientRequest.msgData.infoCheckIn.pidCliente;
    database->listClients[indexClient].pidServidorDedicado = getpid();

    // Libera o semáforo após atualizar a informação
    sem_op.sem_op = 1; // Incrementa o semáforo para desbloquear
    if (semop(semId, &sem_op, 1) == -1) {
        so_error("SD13", "Erro ao desbloquear o semáforo SEM_PASSAGEIROS");
        so_debug("> [@return:%d]", result);
        return result; // Retorna erro se não conseguir desbloquear o semáforo
    }

    // SD13.5 Dá so_success "End Check-in: <NIF> <pidCliente>"
    so_success("SD13.5", "End Check-in: %d %d", clientRequest.msgData.infoCheckIn.nif, clientRequest.msgData.infoCheckIn.pidCliente);
    result = RETURN_SUCCESS; // Sucesso

  

    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief SD14: Ler a descrição da tarefa no enunciado
 * @param erroValidacoes booleano que diz se houve algum erro nas validações de SD11, SD12 e SD13
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */

int sendResponseClient_SD14 (int erroValidacoes) {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("< [@param erroValidacoes:%d]", erroValidacoes);

 MsgContent response;
    response.msgType = clientRequest.msgData.infoCheckIn.pidCliente; // SD14: Tipo de mensagem é o PID do Cliente

    if (erroValidacoes) {
        // SD14.1 Se houve qualquer erro nas validações
        response.msgData.infoCheckIn.pidServidorDedicado = PID_INVALID;
        so_error("SD14.1", "Erro nas validações dos passos SD11, SD12, ou SD13");
    } else {
        // Caso contrário, preenche a mensagem com os dados do voo
        response.msgData.infoCheckIn.pidServidorDedicado = getpid();
        response.msgData.infoCheckIn.lugarEscolhido = EMPTY_SEAT;
        response.msgData.infoVoo = database->listFlights[indexFlight]; // Preenche a estrutura infoVoo
        so_success("SD14.1", "Preenchimento da mensagem de resposta");
    }

    // SD14.2 Envia a mensagem para a MSG
    if (msgsnd(msgId, &response, sizeof(response.msgData), 0) == -1) {
        so_error("SD14.2", "Erro ao enviar a mensagem para o cliente");
        so_debug("> [@return:%d]", result);
        return result; // Retorna erro se houver problema no envio
    }

    so_success("SD14.2", "Mensagem enviada para o cliente com sucesso");
    result = RETURN_SUCCESS; // Sucesso

    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief SD15: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int readResponseClient_SD15 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");
 
    if (msgrcv(msgId, &clientRequest, sizeof(clientRequest.msgData), getpid(), 0) == -1) {
        so_error("SD15", "Erro ao ler a mensagem do cliente");
        return result;
    }

    so_success("SD15", "%d %d %d", clientRequest.msgData.infoCheckIn.nif, clientRequest.msgData.infoCheckIn.lugarEscolhido, clientRequest.msgData.infoCheckIn.pidCliente);
    result = RETURN_SUCCESS;

    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief SD16: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int updateFlightDB_SD16 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    int lugarEscolhido = clientRequest.msgData.infoCheckIn.lugarEscolhido;
    int nif = clientRequest.msgData.infoCheckIn.nif;
    char* nrVoo = database->listFlights[indexFlight].nrVoo;

    // SD16.1 
    so_success("SD16.1", "Start Reserva lugar: %s %d %d", nrVoo, nif, lugarEscolhido);

    struct sembuf sops; // estrutura para operação do semáforo

    // bloqueia o semáforo   
    sops.sem_num = SEM_VOOS;
    sops.sem_op = -1; // Decrementa o semáforo para lock
    sops.sem_flg = 0;

    if (semop(semId, &sops, 1) == -1) {
        so_error("SD16", "Erro ao bloquear o semáforo");
        return result;
    }

    // SD16.2 
    if (database->listFlights[indexFlight].lugares[lugarEscolhido] != EMPTY_SEAT) {
        // desbloqueia o semáforo se o lugar já estiver ocupado
        sops.sem_op = 1; // incrementa o semáforo para unlock
        semop(semId, &sops, 1);

        so_error("SD16.2", "Cliente %d: Lugar já estava ocupado", nif);
        return result;
    }

    // SD16.3
    sleep(4);

    // SD16.4 
    database->listFlights[indexFlight].lugares[lugarEscolhido] = nif;

    // SD16.5
    database->listClients[indexClient].lugarEscolhido = lugarEscolhido;

    // desbloqueia o semáforo depois de atualizar os dados
    sops.sem_op = 1; // incrementa o semáforo para unlock
    semop(semId, &sops, 1);

    // SD16.6 
    so_success("SD16.6", "End Reserva lugar: %s %d %d", nrVoo, nif, lugarEscolhido);
    result = RETURN_SUCCESS;

    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief SD17: Ler a descrição da tarefa no enunciado
 * @return RETURN_SUCCESS (0) em caso de sucesso, ou RETURN_ERROR (-1) em caso de erro
 */
int sendConfirmationClient_SD17 () {
    int result = RETURN_ERROR; // Por omissão, retorna erro
    so_debug("<");

    MsgContent confirmation;
    confirmation.msgType = clientRequest.msgData.infoCheckIn.pidCliente; 

    confirmation.msgData.infoCheckIn.pidServidorDedicado = getpid(); 
    confirmation.msgData.infoCheckIn.lugarEscolhido = clientRequest.msgData.infoCheckIn.lugarEscolhido;

    strcpy(confirmation.msgData.infoVoo.origem, database->listFlights[indexFlight].origem);
    strcpy(confirmation.msgData.infoVoo.destino, database->listFlights[indexFlight].destino);

    if (msgsnd(msgId, &confirmation, sizeof(confirmation.msgData), 0) == -1) {
        so_error("SD17", "Erro ao enviar a mensagem de confirmação para o cliente");
        return result;
    }

    so_success("SD17", "Mensagem de confirmação enviada para o cliente com sucesso");
    result = RETURN_SUCCESS;

    so_debug("> [@return:%d]", result);
    return result;
}

/**
 * @brief SD18: Ler a descrição da tarefa no enunciado
 */
void terminateServidorDedicado_SD18 () {
    so_debug("<");

    if (indexClient >= 0) {
        database->listClients[indexClient].pidCliente = PID_INVALID;
        database->listClients[indexClient].pidServidorDedicado = PID_INVALID;

        so_success("SD18", "Atualização do passageiro concluída: NIF %d", database->listClients[indexClient].nif);
    }

    so_debug(">");
    exit(0);
}

/**
 * @brief SD19: Ler a descrição da tarefa no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGUSR1_SD19 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    so_success("SD19", "SD: Recebi pedido do Cliente para terminar");
    terminateServidorDedicado_SD18();

    so_debug(">");
}

/**
 * @brief SD20: Ler a descrição da tarefa no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGUSR2_SD20 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    so_success("SD20", "SD: Recebi pedido do Servidor para terminar");

    if (clientRequest.msgData.infoCheckIn.pidCliente != PID_INVALID) {
        kill(clientRequest.msgData.infoCheckIn.pidCliente, SIGHUP);
    }

    terminateServidorDedicado_SD18();

    so_debug(">");
}