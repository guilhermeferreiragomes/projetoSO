#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. so_utils.sh                       ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024
##
## Aluno: Nº:122976       Nome:Guilherme Gomes
## Nome do Módulo: S3. Script: estado_voos.sh
## Descrição/Explicação do Módulo: Módulo responsável por gerar um relatório dos voos disponiveis e cria uma pagina html referente à listagem de voos disponiveis.
##
##
###############################################################################

## Este script não recebe nenhum argumento, e é responsável pelo relatório do estado dos voos que pertencem à plataforma IscteFlight.
## S3.1. Validações:
## S3.1.1. O script valida se o ficheiro voos.txt existe. Se não existir, dá so_error e termina. Senão, dá so_success.

if [ ! -f "voos.txt" ]; then
   so_error S3.1.1
   exit 1
else
   so_success S3.1.1
fi

## S3.1.2. O script valida se os formatos de todos os campos de cada linha do ficheiro voos.txt correspondem à especificação indicada em S2, nomeadamente se respeitam os formatos de data e de hora. Se alguma linha não respeitar, dá so_error <conteúdo da linha> e termina. Caso contrário, dá so_success.


## S3.2. Processamento do script:

## S3.2.1. O script cria uma página em formato HTML, chamada voos_disponiveis.html, onde lista os voos com lugares disponíveis, indicando nº, origem, destino, data, hora, lotação, nº de lugares disponíveis, e nº de lugares ocupados (para isso deve calcular a diferença dos anteriores). Em caso de erro (por exemplo, se não conseguir escrever no ficheiro), dá so_error e termina. Caso contrário, dá so_success.

DataReserva=$(date --rfc-3339=date)
HoraReserva=$(date --rfc-3339=seconds | cut -d " " -f2 | cut -d+ -f1)

echo '<html><head><meta charset="UTF-8"><title>IscteFlight: Lista de Voos Disponíveis</title></head>
<body><h1>Lista atualizada em '$DataReserva' '$HoraReserva'</h1>' > voos_disponiveis.html
while IFS= read line; do
    if ! [ $(echo "$line" | cut -d: -f8) -eq 0 ]; then
        NrVoo=$(echo $line | cut -d: -f1 )
        Origem=$(echo $line | cut -d: -f2 )
        Destino=$(echo $line | cut -d: -f3 )
        DataPartida=$(echo $line | cut -d: -f4 )
        HoraPartida=$(echo $line | cut -d: -f5 )
        Lotacao=$(echo $line | cut -d: -f7 )
        LugaresDisp=$(echo $line | cut -d: -f8 )
        LugaresOcupados=$(( Lotacao - LugaresDisp))
        echo "<h2>Voo: $NrVoo, De: $Origem Para: $Destino, Partida em $DataPartida $HoraPartida</h2>
        <ul>
        <li><b>Lotação:</b> $Lotacao Lugares</li>
        <li><b>Lugares Disponíveis:</b> $LugaresDisp Lugares</li>
        <li><b>Lugares Ocupados:</b> $LugaresOcupados Lugares</li>
        </ul>" >> voos_disponiveis.html
    fi
done < voos.txt
echo "</body></html>" >> voos_disponiveis.html

if ! [[ ! -f voos_disponiveis.html || $(cat voos_disponiveis.html | wc -l) -eq 0 ]]; then
    so_success S3.2.1
else
    so_error S3.2.1
fi

## S3.3. Invocação do script estado_voos.sh:

## S3.3.1. Altere o ficheiro cron.def fornecido, por forma a configurar o seu sistema para que o script seja executado de hora em hora, diariamente. Nos comentários no início do ficheiro cron.def, explique a configuração realizada, e indique qual o comando que deveria utilizar para despoletar essa configuração. O ficheiro cron.def alterado deverá ser submetido para avaliação juntamente com os outros Shell scripts.





