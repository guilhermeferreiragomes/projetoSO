/******************************************************************************
 ** ISCTE-IUL: Trabalho prático 2 de Sistemas Operativos 2023/2024, Enunciado Versão 3+
 **
 ** Aluno: Nº:122976       Nome:Guilherme Gomes 
 ** Nome do Módulo: servidor.c
 ** Descrição/Explicação do Módulo:
 **
 **
 ******************************************************************************/

#define SO_HIDE_DEBUG                // Uncomment this line to hide all @DEBUG statements
#include "common.h"

/*** Variáveis Globais ***/
CheckIn clientRequest; // Variável que tem o pedido enviado do Cliente para o Servidor

/**
 * @brief Processamento do processo Servidor e dos processos Servidor Dedicado
 *        "os alunos não deverão alterar a função main(), apenas compreender o que faz.
 *         Deverão, sim, completar as funções seguintes à main(), nos locais onde está claramente assinalado
 *         '// Substituir este comentário pelo código da função a ser implementado pelo aluno' "
 */
int main () {
    // S1
    checkExistsDB_S1(FILE_DATABASE);
    // S2
    createFifo_S2(FILE_REQUESTS);
    // S3
    triggerSignals_S3(FILE_REQUESTS);

    int indexClient;       // Índice do cliente que fez o pedido ao servidor/servidor dedicado na BD

    // S4: CICLO1
    while (TRUE) {
        // S4
        clientRequest = readRequest_S4(FILE_REQUESTS); // S4: "Se houver erro (...) clientRequest.nif == -1"
        if (clientRequest.nif < 0)   // S4: "Se houver erro na abertura do FIFO ou na leitura do mesmo, (...)"
            continue;                // S4: "(...) e recomeça o Ciclo1 neste mesmo passo S4, lendo um novo pedido"

        // S5
        int pidServidorDedicado = createServidorDedicado_S5();
        if (pidServidorDedicado > 0) // S5: "o processo Servidor (pai) (...)"
            continue;                // S5: "(...) recomeça o Ciclo1 no passo S4 (ou seja, volta a aguardar novo pedido)"
        // S5: "o Servidor Dedicado (que tem o PID pidServidorDedicado) segue para o passo SD9"

        // SD9
        triggerSignals_SD9();
        // SD10
        CheckIn itemBD;
        indexClient = searchClientDB_SD10(clientRequest, FILE_DATABASE, &itemBD);
        // SD11
        checkinClientDB_SD11(&clientRequest, FILE_DATABASE, indexClient, itemBD);
        // SD12
        sendAckCheckIn_SD12(clientRequest.pidCliente);
        // SD13
        closeSessionDB_SD13(clientRequest, FILE_DATABASE, indexClient);
        so_exit_on_error(-1, "ERRO: O servidor dedicado nunca devia chegar a este ponto");
    }
}

/**
 *  "O módulo Servidor é responsável pelo processamento do check-in dos passageiros. 
 *   Está dividido em duas partes, um Servidor (pai) e zero ou mais Servidores Dedicados (filhos).
 *   Este módulo realiza as seguintes tarefas:"
 */

/**
 * @brief S1     Ler a descrição da tarefa S1 no enunciado
 * @param nameDB O nome da base de dados (i.e., FILE_DATABASE)
 */
void checkExistsDB_S1 (char *nameDB) {
    so_debug("< [@param nameDB:%s]", nameDB);               //SE NAO FUNCIONAR FAZER COM ACCESS
    FILE *file;
    
    file = fopen(nameDB, "r");
    if(file == NULL) {
        so_error("S1", "O ficheiro %s não existe não existe", nameDB);
    }
    else {
        fclose(file);
        so_success("S1", "O ficheiro %s exite", nameDB);
    }

    file = fopen(nameDB, "r+");
    if(file ==  NULL) {
        so_error("S1", "Não tem permissões no ficheiro %s", nameDB);
        exit(1);
    }
    else {
        fclose(file);
        so_success("S1", "O ficheiro %s pode ser lido e escrito", nameDB);
    }

    so_debug(">");
}

/**
 * @brief S2       Ler a descrição da tarefa S2 no enunciado
 * @param nameFifo O nome do FIFO do servidor (i.e., FILE_REQUESTS)
 */
void createFifo_S2 (char *nameFifo) {
    so_debug("< [@param nameFifo:%s]", nameFifo);

    // Tentar remover o FIFO se ele já existir
    if (access(nameFifo, F_OK) == 0) {
        if (remove(nameFifo) != 0) {
            so_error("S2", "Erro ao remover o FIFO existente.\n");
            exit(1);
        }
    }

    // Tentar criar o FIFO
    if (mkfifo(nameFifo, 0666) != 0) {
        // Se houver erro ao criar o FIFO, imprimir uma mensagem de erro e abortar
        so_error("S2","Erro ao criar o FIFO.\n");
        exit(1);
    } else {
        // Se o FIFO for criado com sucesso, imprimir uma mensagem de sucesso
        so_success("S2","FIFO criado com sucesso.\n");
    }

    so_debug(">");
}

/**
 * @brief S3   Ler a descrição da tarefa S3 no enunciado
 */
void triggerSignals_S3 () {
    so_debug("<");

    if (signal(SIGINT, trataSinalSIGINT_S6) == SIG_ERR || signal(SIGCHLD, trataSinalSIGCHLD_S8) == SIG_ERR) {
        so_error("S3", "Erro ao armar um ou mais sinais.");
        deleteFifoAndExit_S7();
    } else {
        so_success("S3", "Sinais armados com sucesso.");
    }
    so_debug(">");
}

/**
 * @brief S4       O CICLO1 já está a ser feito na função main(). Ler a descrição da tarefa S4 no enunciado
 * @param nameFifo O nome do FIFO do servidor (i.e., FILE_REQUESTS)
 * @return CheckIn Elemento com os dados preenchidos. Se nif=-1, significa que o elemento é inválido
 */
CheckIn readRequest_S4 (char *nameFifo) {
    CheckIn request;
    request.nif = -1;  // Por omissão retorna erro
    so_debug("< [@param nameFifo:%s]", nameFifo);

    FILE *arquivo = fopen(nameFifo, "r");
    if (arquivo == NULL) {
        so_error("S4", "", nameFifo);
        exit(1);  //termina o processo caso não consiga abrir o FIFO
    }
    //ler dados do fifo
    if (fscanf(arquivo, "%d\n%s\n%d\n", &request.nif, request.senha, &request.pidCliente) != 3) {
        so_error("S4.1", "", nameFifo);
        fclose(arquivo);
        exit(1);  //termina
    }
    //validação dos dados
    if (request.nif < 0 || request.nif > 999999999 || request.pidCliente < 0) {
        so_error("S4.1", "Dados inválidos '%s'", nameFifo);
        deleteFifoAndExit_S7();
        request.nif = -1;
        request.pidCliente = -1;
        fclose(arquivo);
        exit(1);  //termina
    }
    fclose(arquivo);
    so_success("S4.1", "%d %s %d", request.nif, request.senha, request.pidCliente);
    so_debug("> [@return nif:%d, senha:%s, pidCliente:%d]", request.nif, request.senha, request.pidCliente);
    return request;
}
/**
 * @brief S5   Ler a descrição da tarefa S5 no enunciado
 * @return int PID do processo filho, se for o processo Servidor (pai),
 *             0 se for o processo Servidor Dedicado (filho), ou -1 em caso de erro.
 */
int createServidorDedicado_S5 () {
    int pid_filho = -1;    // Por omissão retorna erro
    so_debug("<");

// Criar um novo processo filho (Servidor Dedicado)
    pid_filho = fork();

    if (pid_filho == -1) {
        // Erro ao criar o processo filho
        so_error("S5", "Erro ao criar o processo filho.\n");
        deleteFifoAndExit_S7();

    } else if (pid_filho > 0) {
        // Processo pai (Servidor)
        so_success("S5", "Servidor: Iniciei SD %d\n", pid_filho);
        return pid_filho; // Retorna o PID do filho no pai

    } else {
        // Processo filho (Servidor Dedicado)
        triggerSignals_SD9(); // Configura os sinais SIGUSR2 e SIGINT
        return 0; // Retorna 0 no processo filho
    }
    so_debug("> [@return:%d]", pid_filho);
    return pid_filho;
}

/**
 * @brief S6            Ler a descrição das tarefas S6 e S7 no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGINT_S6(int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    // Imprimir mensagem de sucesso indicando o início do processo de encerramento do Servidor
    so_success("S6", "Servidor: Start Shutdown\n");

    // S6.1: Abrir o arquivo de base de dados para leitura
    FILE *file = fopen(FILE_DATABASE, "r");
    if (file == NULL) {
        // Em caso de erro na abertura do arquivo, imprimir mensagem de erro e encerrar o Servidor
        so_error("S6.1", "Erro ao abrir o arquivo de base de dados para leitura.\n");
        deleteFifoAndExit_S7();
        return;
    }
    so_success("S6.1", "");

    // S6.2: Ler os dados do arquivo de base de dados
    so_debug("Servidor: Shutdown\n"); // Mensagem indicando o início do processo de shutdown

    CheckIn itemDB;
    while (fread(&itemDB, sizeof(CheckIn), 1, file) == 1) {
        // S6.3: Enviar sinal SIGUSR2 para os Servidores Dedicados
        if (itemDB.pidServidorDedicado > 0) {
            // Enviar sinal SIGUSR2 para terminar o Servidor Dedicado
            if (kill(itemDB.pidServidorDedicado, SIGUSR2) != 0) {
                so_error("S6.3", "Erro ao enviar sinal SIGUSR2 para PID %d\n", itemDB.pidServidorDedicado);
            } else {
                so_success("S6.3", "Servidor: Shutdown SD %d\n", itemDB.pidServidorDedicado);
            }
        }
    }
    // S6.4: Fechar o arquivo de base de dados
    fclose(file);

    // Esperar um curto período de tempo para permitir que os Servidores Dedicados terminem
    sleep(1);

    // S7: Remover o FIFO do servidor e encerrar o servidor
    so_success("S6.2", "Servidor: End Shutdown\n");
    deleteFifoAndExit_S7();

    so_debug(">");
}

/**
 * @brief S7 Ler a descrição da tarefa S7 no enunciado
 */
void deleteFifoAndExit_S7 () {
    so_debug("<");

    const char *fifoName = "server.fifo";

    // Tentar remover o FIFO do servidor
    if (unlink(fifoName) == -1) {
        // Se houver erro ao remover o FIFO
        so_error("S7", "Erro ao remover FIFO do servidor");
        exit(1); // Encerrar o processo do servidor com erro
    } else {
        // Se o FIFO foi removido com sucesso
        so_success("S7", "Servidor: End Shutdown\n");
        exit(0); // Encerrar o processo do servidor com sucesso
    }
    so_debug(">");
    exit(0);
}

/**
 * @brief S8            Ler a descrição da tarefa S8 no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGCHLD_S8 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    int pid_filho = wait(NULL); //espera que qualquer processo filho termine e guarda o seu pid
    so_success("S8", "Servidor: Confirmo fim de SD %d", pid_filho); //regista success na conclusão do processo filho
        
    so_debug(">");
}

/**
 * @brief SD9  Ler a descrição da tarefa SD9 no enunciado
 */
void triggerSignals_SD9 () {
    so_debug("<");

   // Armar o sinal SIGUSR2 para o novo processo Servidor Dedicado
    if (signal(SIGUSR2, trataSinalSIGUSR2_SD14) == SIG_ERR) {
        // Erro ao armar o sinal SIGUSR2
        so_error("SD9", "Erro ao armar o sinal SIGUSR2 para o Servidor Dedicado");
        exit(1); // Terminar o Servidor Dedicado com erro
    }

    // Armar o sinal SIGINT para o novo processo Servidor Dedicado (ignorá-lo)
    if (signal(SIGINT, SIG_IGN) == SIG_ERR) {
        // Erro ao armar o sinal SIGINT
        so_error("SD9", "Erro ao programar o sinal SIGINT para ser ignorado pelo Servidor Dedicado");
        exit(1); // Terminar o Servidor Dedicado com erro
    }

    // Sucesso ao armar os sinais SIGUSR2 e SIGINT
    so_success("SD9", "Sinais SIGUSR2 e SIGINT aramados para o Servidor Dedicado");
    so_debug(">");
}

/**
 * @brief SD10    Ler a descrição da tarefa SD10 no enunciado
 * @param request O pedido do cliente
 * @param nameDB  O nome da base de dados
 * @param itemDB  O endereço de estrutura CheckIn a ser preenchida nesta função com o elemento da BD
 * @return int    Em caso de sucesso, retorna o índice de itemDB no ficheiro nameDB.
 */
int searchClientDB_SD10(CheckIn request, char *nameDB, CheckIn *itemDB) {
    int indexClient = 0;
    so_debug("< [@param request.nif:%d, request.senha:%s, nameDB:%s, itemDB:%p]", request.nif, request.senha, nameDB, itemDB);    

    FILE *dbFile = fopen(nameDB, "rb");
    if (dbFile == NULL) {
        so_error("SD10", "Não foi possível abrir o banco de dados '%s'", nameDB);
        exit(1);  // encerra o servidor dedicado se não pode abrir o banco de dados
    }

    while (fread(itemDB, sizeof(CheckIn), 1, dbFile)) {
        indexClient++;
        if  (itemDB->nif == request.nif) {
            if (strcmp (itemDB->senha, request.senha) == 0) {
                fclose(dbFile);
                so_success("SD10.3","%d",indexClient);
                return indexClient;
            } else {
                so_error("SD10.3", "Cliente %d: Senha errada", request.nif);
                kill(request.pidCliente, SIGHUP); // envia um sinal de erro ao cliente
                fclose(dbFile);
                exit(1); // encerra o servidor dedicado por senha incorreta
            }
        }
    }

    fclose(dbFile);

    
    so_error("SD10.1", "Cliente %d não encontrado", request.nif);
    kill(request.pidCliente, SIGHUP); // envia sinal de erro ao cliente
    exit(1); // encerra o servidor dedicado por cliente não encontrado
    

    so_success("SD10.3", "%d", indexClient); // dá login com sucesso com o índice do cliente encontrado
    return indexClient;
}


/**
 * @brief SD11        Ler a descrição da tarefa SD11 no enunciado
 * @param request     O endereço do pedido do cliente (endereço é necessário pois será alterado)
 * @param nameDB      O nome da base de dados
 * @param indexClient O índica na base de dados do elemento correspondente ao cliente
 * @param itemDB      O elemento da BD correspondente ao cliente
 */
void checkinClientDB_SD11 (CheckIn *request, char *nameDB, int indexClient, CheckIn itemDB) {
    so_debug("< [@param request:%p, nameDB:%s, indexClient:%d, itemDB.pidServidorDedicado:%d]",
                                    request, nameDB, indexClient, itemDB.pidServidorDedicado);
    //os dados do itemDB
    strcpy(request->nome, itemDB.nome); //copia o nome do passageiro
    strcpy(request->nrVoo, itemDB.nrVoo); //copia o número do voo
    request->pidServidorDedicado = getpid(); //define o PID do processo Servidor Dedicado
    so_success("SD11.1", "%s %s %d", request->nome, request->nrVoo, request->pidServidorDedicado);
    
    //abre o arquivo de banco de dados para leitura e escrita
    FILE *dbFile = fopen(nameDB, "r+");
    if (dbFile == NULL) {
        so_error("SD11.2", ""); //falha ao abrir o arquivo de banco de dados
        kill(request->pidCliente, SIGHUP); //envia o sinal SIGHUP ao cliente
        exit(1);
    }
    so_success("SD11.2", "");

    if (fseek(dbFile, (indexClient-1) * sizeof(CheckIn), SEEK_SET) != 0) {
        so_error("SD11.3", "");
        fclose(dbFile);
        kill(request->pidCliente, SIGHUP); //envia o sinal SIGHUP ao cliente
        exit(1);
    }
    so_success("SD11.3", "");
    //dados atualizados no arquivo
    if (fwrite(request, sizeof(CheckIn), 1, dbFile) != 1) {
        so_error("SD11.1", ""); //falha ao escrever no arquivo
        fclose(dbFile);
        kill(request->pidCliente, SIGHUP); //envia o sinal SIGHUP ao cliente
        exit(1);
    }
    fclose(dbFile);
    so_success("SD11.4", "Dados atualizados e arquivo fechado");
    so_debug("> [nome:%s, nrVoo:%s, pidServidorDedicado:%d]", request->nome,
                                                request->nrVoo, request->pidServidorDedicado);
}

/**
 * @brief SD12       Ler a descrição da tarefa SD12 no enunciado
 * @param pidCliente PID (Process ID) do processo Cliente
 */
void sendAckCheckIn_SD12 (int pidCliente) {
    so_debug("< [@param pidCliente:%d]", pidCliente);
    srand(time(NULL)); //gera random numbers
    //tempo aleatório entre 1 e MAX_ESPERA segundos
    int waitTime = (rand() % MAX_ESPERA) + 1; //adiciona 1 para garantir que o tempo mínimo é 1 segundo
    so_success("SD12", "%d", waitTime);
    sleep(waitTime); //espera pelo waitTime
    kill(pidCliente, SIGUSR1); //envia o sinal SIGUSR1 ao processo cliente para indicar que o check-in foi concluído
    so_debug(">");
}

/**
 * @brief SD13          Ler a descrição da tarefa SD13 no enunciado
 * @param clientRequest O endereço do pedido do cliente
 * @param nameDB        O nome da base de dados
 * @param indexClient   O índica na base de dados do elemento correspondente ao cliente
 */
void closeSessionDB_SD13 (CheckIn clientRequest, char *nameDB, int indexClient) {
    so_debug("< [@param clientRequest:%p, nameDB:%s, indexClient:%d]", &clientRequest, nameDB,
                                                                                    indexClient);
    clientRequest.pidCliente = -1; //para "limpar"
    clientRequest.pidServidorDedicado = -1;
    FILE *dbFile = fopen(nameDB, "r+"); 
    if (dbFile == NULL) {
        so_error("SD13.1", ""); //falha ao abrir o arquivo
        exit(1);
    } else {
        so_success("SD13.1", "");
    }
    if (fseek(dbFile, (indexClient-1) * sizeof(CheckIn), SEEK_SET) != 0) {
        so_error("SD13.2", "");
        fclose(dbFile);
        exit(1);
    } else {
        so_success("SD13.2", "");
    }

    if (fwrite(&clientRequest, sizeof(CheckIn), 1, dbFile) != 1) {
        so_error("SD13.3", "");
        fclose(dbFile);
        exit(1);
    } else {
        so_success("SD13.3", "");
    }
    fclose(dbFile);
    exit(1);
    so_debug("> [pidCliente:%d, pidServidorDedicado:%d]", clientRequest.pidCliente, 
                                                          clientRequest.pidServidorDedicado);
}

/**
 * @brief SD14          Ler a descrição da tarefa SD14 no enunciado
 * @param sinalRecebido nº do Sinal Recebido (preenchido pelo SO)
 */
void trataSinalSIGUSR2_SD14 (int sinalRecebido) {
    so_debug("< [@param sinalRecebido:%d]", sinalRecebido);

    so_success("SD14", "SD: Recebi pedido do Servidor para terminar");

    exit(0);

    so_debug(">");
}